root/
├─ index.html
├─ style.css
├─ layer1/
│   ├─ index.html
│   └─ layer2/
│       ├─ index.html
│       └─ layer3/
│           └─ index.html
├─ nodes/
│   ├─ node_a.html
│   └─ node_b.html
├─ secrets/
│   ├─ secret1.html
│   └─ secret2.html
└─ sitemap.html